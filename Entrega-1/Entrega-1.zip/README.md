#### 4.a) Dado uma coleção de salários, criar uma classe com os seguintes métodos:

 * a) Obter(ler) os salários;

 * b) Determinar qual o maior salário; 

 * c) Calcular a média dos salários;

 * d) Contar quantos salários são menores que 1000 (mil reais).


